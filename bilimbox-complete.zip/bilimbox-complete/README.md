# BilimBox Complete

Бул сага даяр иштей турган **мультиязычный билим платформасынын старттык версиясы**.

Ичинде бар:
- Next.js 14
- Tailwind CSS
- Prisma
- SQLite
- KG / RU / EN тилдери
- Главная
- Курстар каталогу
- Курс барагы
- Сабак барагы
- Dashboard
- Admin analytics
- API routes
- Docker
- Dev Container

## Эмне үчүн ушул версияны тандадым
Сен мурда компьютерге көп нерсе орнотпой эле, бир жерде иштей турган вариант каалагансың. Ошондуктан бул версия:
- **бир проекттин ичинде**
- **backend + frontend бир жерде**
- **SQLite менен дароо иштейт**
- кийин PostgreSQL'ге оңой көчөт

## Локалда иштетүү
```bash
cp .env.example .env
npm install
npm run db:push
npm run db:seed
npm run dev
```

Анан ач:
```bash
http://localhost:3000
```

## Docker менен
```bash
docker compose up --build
```

## GitHub Codespaces / Dev Container
Бул проектке `.devcontainer` кошулган. GitHub'га жүктөп, Codespaces'та ачсаң болот.

## Маршруттар
- `/kg`
- `/ru`
- `/en`
- `/kg/courses`
- `/kg/dashboard`
- `/kg/admin`

## Демо маалымат
Seed кийин төмөнкү demo user түзүлөт:
- email: `demo@bilimbox.kg`
- role: `admin`

## API
### Курстар
`GET /api/courses?locale=kg`

### Курс кошулуу
`POST /api/enroll`
```json
{ "slug": "computer-zero-to-pro" }
```

### Прогресс жаңыртуу
`POST /api/progress`
```json
{ "lessonSlug": "what-is-computer" }
```

## Эми дагы эмне кошуш керек
Бул версия **иштей турган MVP foundation**. Бирок чыныгы production үчүн кийин кошулат:
- auth (NextAuth / custom JWT)
- реальный payment
- Telegram bot webhook
- file upload / S3
- quiz engine
- certificate generator
- SEO
- email / SMS notifications
- admin CRUD
- analytics charts

## Онлайн иштетүү
Эң жеңил варианттар:
- Vercel
- GitHub Codespaces
- Replit

## Сен үчүн кийинки этап
Бул архивди ачып иштеткенден кийин, кийинки версияга өтөбүз:
1. Реальный auth
2. Payment
3. Telegram Sync
4. Course CRUD admin
5. Certificate
6. Quiz system
