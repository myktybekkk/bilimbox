import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'BilimBox',
  description: 'Multilingual learning platform for courses, lessons, quizzes and progress tracking.'
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
